function logoutMe() {
    var response = confirm("Are you sure you want to log out of this Account?");
    if (response == true){
        $('#signupMenu').show();
        $('#loginMenu').show();
        $('#logoutMenu').hide();
        sessionStorage.removeItem("token");
        sessionStorage.removeItem("userName")
        window.location.href="index.html"
    }

}
