var restaurants_url = "/restaurants/searchbar";


var restaurants_array = []; // This creates an empty restaurant array
var restaurantsCount = 0;

var currentIndex = 0;

var review_url = "/reviews";

var review_array = []; //This creats an empty review array

email_url = "/email"

var heartBWImage = 'images/heart_bw.png';
var heartImage = 'images/heart.png';
var rating = 0;

var adduserProfiles_url = '/signup';
var userProfiles_array = [];

var userProfiles_url = '/login';

var updateUserprofiles_url = '/users';

function CheckToken(){
    var token = sessionStorage.getItem("token");
    if (token != null) {
        $('#signupMenu').hide();
        $('#loginMenu').hide();
        $('#logoutMenu').show();
        $('#userprofileMenu').show();
    } 
}

