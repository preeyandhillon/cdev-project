function signUpMe(){

    var signupUser = new XMLHttpRequest();

    signupUser.open("POST", adduserProfiles_url, true);
    signupUser.setRequestHeader("Content-Type", "application/json");
    signupUser.onload=function(){

        $('#signupMenu').hide();
        $('#authorisedModal').modal('show');
        encode1(); 
        window.location.href="login.html"


    }
    var userName = document.getElementById("Username").value;
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var password = document.getElementById("password").value;
    var emailAddress = document.getElementById("emailAddress").value;
    var gender = document.getElementById("gender").value;
    var address = document.getElementById("address").value;
    var number = document.getElementById("number").value;
    var profileImage = document.getElementById("target1").src;
    
    var payload = {userName:userName, firstName:firstName, lastName:lastName, password:password, emailAddress:emailAddress, gender:gender, address:address, number:number, profileImage:profileImage}
    signupUser.send(JSON.stringify(payload));


}


function encode1(){

    var selectedfile = document.getElementById("UserprofileprofileImage1").files;
    if (selectedfile.length > 0) {
        var imageFile = selectedfile[0];
        var fileReader = new FileReader();
        fileReader.onload = function ( fileLoadedEvent) {
            profileImage = fileLoadedEvent.target.result;
            document.getElementById('target1').src = profileImage

        }
        fileReader.readAsDataURL(imageFile);
    }
}    