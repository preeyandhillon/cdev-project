function getUserprofiles(){
    var request = new XMLHttpRequest();
    request.open('GET', userProfiles_url, true);

    //This command starts the calling of the userprofiles api
    request.onload = function() {
    //get all the user profile records into our userProfiles array
    userProfiles_array = JSON.parse(request.responseText);
    editUserprofiles();

    };

    request.send();
}




function editUserprofiles(){

    sessionStorage.getItem("userName");
    for (var x = 0; x < userProfiles_array.length; x++)
        if (userProfiles_array[x].userName == sessionStorage.getItem("userName")){
            document.getElementById("UserprofileUsername").value = userProfiles_array[x].userName;
            document.getElementById("UserprofilePassword").value = userProfiles_array[x].password;
            document.getElementById("UserprofileFirstname").value = userProfiles_array[x].firstName;
            document.getElementById("UserprofileLastname").value = userProfiles_array[x].lastName;
            document.getElementById("UserprofileEmailaddress").value = userProfiles_array[x].emailAddress;
            document.getElementById("UserprofileGender").value = userProfiles_array[x].gender;
            document.getElementById("UserprofileAddress").value = userProfiles_array[x].address;
            document.getElementById("UserprofileNumber").value = userProfiles_array[x].number;
            document.getElementById("target").src = userProfiles_array[x].profileImage;
        };
    
}

function updateUserprofiles(){
    var response = confirm("Are you sure you want to update your Profile?");
    for(var x = 0; x < userProfiles_array.length; x++)
        if (userProfiles_array[x].userName == sessionStorage.getItem("userName")) {
        var edit_profile_url = updateUserprofiles_url + "/" + userProfiles_array[x]._id;
        var updateUserprofiles = new XMLHttpRequest(); //sending request to server via Http request
        updateUserprofiles.onload=function(){

         
            $('#authorisedModal').modal('show'); 
            

        }
        updateUserprofiles.open("PUT", edit_profile_url, true); //Updating the data 
        updateUserprofiles.setRequestHeader("Content-Type", "application/json");
        userProfiles_array[x].userName = document.getElementById("UserprofileUsername").value;
        userProfiles_array[x].password = document.getElementById("UserprofilePassword").value;
        userProfiles_array[x].firstName = document.getElementById("UserprofileFirstname").value;
        userProfiles_array[x].lastName = document.getElementById("UserprofileLastname").value;
        userProfiles_array[x].emailAddress = document.getElementById("UserprofileEmailaddress").value;
        userProfiles_array[x].gender = document.getElementById("UserprofileGender").value;
        userProfiles_array[x].address = document.getElementById("UserprofileAddress").value;
        userProfiles_array[x].number = document.getElementById("UserprofileNumber").value;
        userProfiles_array[x].profileImage = document.getElementById("target").src;
        updateUserprofiles.onload = function() {
        getUserprofiles(); 
        window.location.href="index.html"
        window.alert("You have successfully updated your profile")
        };
        updateUserprofiles.send(JSON.stringify(userProfiles_array[x]));
        }
    }





function encode(){

    var selectedfile = document.getElementById("UserprofileprofileImage").files;
    if (selectedfile.length > 0) {
        var imageFile = selectedfile[0];
        var fileReader = new FileReader();
        fileReader.onload = function ( fileLoadedEvent) {
            profileImage = fileLoadedEvent.target.result;
            document.getElementById('target').src = profileImage

        }
        fileReader.readAsDataURL(imageFile);
    }
}       


