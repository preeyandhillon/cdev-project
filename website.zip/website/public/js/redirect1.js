$(document).ready(function(){

    var token = sessionStorage.getItem("token");
    if (token != null) {
        $('#signupMenu').hide();
        $('#loginMenu').hide();
        $('#logoutMenu').show();
        $('#userprofileMenu').show();
        
    } 
    

    
        
})  