

function searchAllRestaurants() {

    var request = new XMLHttpRequest();

    
    request.open("POST", "http://localhost:8080/restaurants/searchbar", true);
    request.setRequestHeader("Content-Type", "application/json");
    request.onload = function () {

        restaurants_array = JSON.parse(request.responseText);

        fetchReviews();

        var cuisine ="All";
        displayRestaurants(cuisine);
 

    };
    


    var search = document.getElementById("searchBar").value;

    var payload = { search: search }

    request.send(JSON.stringify(payload));
    
}



function displayRestaurants(cuisine) 
{    
    var table = document.getElementById("restaurantsTable");    
    var restaurantsCount = 0;    
    var message = "";    

    console.log(cuisine)
    table.innerHTML = "";    
    totalRestaurants = restaurants_array.length;    
    if(cuisine == "All"){
        for (var count = 0; count < totalRestaurants; count++) 
        {       
            var thumbnail = restaurants_array[count].thumbnail;            
            var title = restaurants_array[count].restaurantName;            
            var cell = '<div class="col-md-3" style="float: none; margin: 0 auto;">' +                          
                            '<div class="flip-container" >' +              
                                '<div class="flipper">' +
                                    '<div class="front">' + 
                                        '<a id="restaurants" href="#" data-toggle="modal" data-target="#restaurantsModal" item=' + count + '>'+
                                            '<img class="img-fluid img-thumbnail" src=' + thumbnail + ' />'+
                                        '</a>'+
                                    '</div>'+                              
                                    '<div class="back">'+                                   
                                        '<div class="bg-dark mystyle text-center py-3" >'+
                                            '<span>' + title + '</span><br>' +
                                            '<button href="#" data-toggle="modal" data-target="#restaurantsModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showRestaurantDetails(this)" >Restaurant Details</button>'+                     
                                            '<button href="#" data-toggle="modal" data-target="#reviewModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showRestaurantReview(this)" >Reviews</button>'+
                                            '<button href="#" data-toggle="modal" data-target="#mapModal" item="' + count + '" type="button" class="btn btn-warning btn-sm" onClick="showMap(this)" >Map</button>'+

                                        '</div>'+
                                    '</div>'+
                                '</div>' +
                            '</div>' +
                        '</div>';    

            table.insertAdjacentHTML('beforeend', cell);            
            restaurantsCount++;        
                
        }    
    }
    else{
        console.log(cuisine)
        for (var count = 0; count < totalRestaurants; count++) {
            if (cuisine == restaurants_array[count].cuisine){
                var thumbnail = restaurants_array[count].thumbnail;            
                var title = restaurants_array[count].restaurantName;            
                var cell = '<div class="col-md-3" style="float: none; margin: 0 auto;">' +                          
                                '<div class="flip-container" >' +              
                                    '<div class="flipper">' +
                                        '<div class="front">' + 
                                            '<a id="restaurants" href="#" data-toggle="modal" data-target="#restaurantsModal" item=' + count + '>'+
                                                '<img class="img-fluid img-thumbnail" src=' + thumbnail + ' />'+
                                            '</a>'+
                                        '</div>'+                              
                                        '<div class="back">'+                                   
                                            '<div class="bg-dark mystyle text-center py-3" >'+
                                                '<span>' + title + '</span><br>' +
                                                '<button href="#" data-toggle="modal" data-target="#restaurantsModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showRestaurantDetails(this)" >Restaurant Details</button>'+                     
                                                '<button href="#" data-toggle="modal" data-target="#reviewModal" item="' + count + '" type="button" class="btn btn-primary btn-sm" onClick="showRestaurantReview(this)" >Reviews</button>'+
                                                '<button href="#" data-toggle="modal" data-target="#mapModal" item="' + count + '" type="button" class="btn btn-warning btn-sm" onClick="showMap(this)" >Map</button>'+
    
                                            '</div>'+
                                        '</div>'+
                                    '</div>' +
                                '</div>' +
                            '</div>';    
    
                table.insertAdjacentHTML('beforeend', cell);            
                restaurantsCount++;  
            }
        }
    }
    message = restaurantsCount + " Restaurants ";    
    document.getElementById("summary").textContent = message;    
    document.getElementById("parent").textContent = "";

}









//This function displays all the restaurants in the database
function AllRestaurants() {
    category = "All Restaurants";
    displayRestaurants();
    document.getElementById("allRestaurants").classList.add("active");

}

//This function displays individual restaurant's details
function showRestaurantDetails(element) {
    var item = element.getAttribute("item");
    currentIndex = item;
    document.getElementById("restaurantName").textContent = restaurants_array[item].restaurantName;
    document.getElementById("caroImage1").src = restaurants_array[item].caroImage1;
    document.getElementById("caroImage2").src = restaurants_array[item].caroImage2;
    document.getElementById("cuisine").textContent = restaurants_array[item].cuisine;
    document.getElementById("openingHours").textContent = restaurants_array[item].openingHours;
    document.getElementById("restaurantPrice").textContent = restaurants_array[item].restaurantPrice;
    document.getElementById("websiteAddress").textContent = restaurants_array[item].websiteAddress;
    document.getElementById("restaurantAddress").textContent = restaurants_array[item].address;
    document.getElementById("restaurantNumber").textContent = restaurants_array[item].number;
    document.getElementById("neighbourhood").textContent = restaurants_array[item].neighbourhood;
}




function showMap(element) {
    var item = element.getAttribute("item");
    currentIndex = item; 
    var locations = [restaurants_array[item].longitude,restaurants_array[item].latitude];
    map = new google.maps.Map(document.getElementById("map"),{center:{lat:1.8, lng:110.9},zoom:4});
    var infowindow = new google.maps.InfoWindow();
    var marker, i;
    var markers =[];

    marker = new google.maps.Marker({
        position : new google.maps.LatLng(locations[0],locations[1]),
        map:map,
        icon:{
            url: "https://maps.google.com/mapfiles/ms/icons/restaurant.png"

        }
    });

    markers.push(marker);
    google.maps.event.addListener(marker,'click', (function (marker, i){
        return function (){
            infowindow.setContent(locations[0]);    
            infowindow.open(map.marker);

        }
    })(marker, i));

    navigator.geolocation.getCurrentPosition(
        (position)=>{
            const pos ={
                lat:position.coords.latitude,
                lng:position.coords.longitude,

            }
            map.setCenter(pos);
            map.setZoom(15);
            marker = new google.maps.Marker({
                position: new google.maps.LatLng(pos.lat, pos.lng),
                map:map,
                icon: {
                    url:"https://maps.google.com/mapfiles/ms/icons/red-dot.png"
                }
            })

            markers.push(marker);
            google.maps.event.addListener(marker,'click', (function (marker, i){
                return function (){
                    infowindow.setContent("Your current location");
                    infowindow.open(map,marker);
        
                }
            })(marker, i));

        }
    )
}







//This function opens a new tab and brings the user to the restuarant's website address
function openWebsite() {
    window.open(restaurants_array[currentIndex].websiteAddress, "_blank");
}






