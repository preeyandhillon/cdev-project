
function sendEmail(){

    var emailUser = new XMLHttpRequest();

    emailUser.open("POST", email_url, true);
    emailUser.setRequestHeader("Content-Type", "application/json");
    emailUser.onload=function(){

        
        

        var token = JSON.parse(emailUser.responseText);
        console.log(token.result);
        if(token.result == "success"){
            
            $('#authorisedModal').modal('show');
        }
        else{
          
            $('#failModal').modal('show');
    
        }
        

    }
    var email = document.getElementById("email").value;
    var content = document.getElementById("content").value;
    var payload = {email:email, content:content}
    emailUser.send(JSON.stringify(payload));

}



// function loginMe(){

//     var loginUser = new XMLHttpRequest();

//     loginUser.open("POST", userProfiles_url, true);
//     loginUser.setRequestHeader("Content-Type", "application/json");
//     loginUser.onload=function(){

        
        

//         var token = JSON.parse(loginUser.responseText);
//         console.log(token.result);
//         if(token.result != false){
            
//             document.getElementById("signupMenu").style.display="none";
//             document.getElementById("loginMenu").style.display="none";
//             document.getElementById("logoutMenu").style.display="block";
//             sessionStorage.setItem("token", token.result);
//             var userName = document.getElementById("usernameLogin").value;
//             sessionStorage.setItem("userName", userName);
//             $('#authorisedModal').modal('show');
//             window.alert("Click 'ok' to be logged-in sucesfully and redirected to the main page")
//             window.location.href="index.html"
            
            
//         }
//         else{
//             window.alert("INCORRECT USERNAME OR PASSWORD!")
        
    
//         }
        

//     }
//     var userName = document.getElementById("usernameLogin").value;
//     var password = document.getElementById("passwordLogin").value;
    
    
//     var payload = {userName:userName, password:password}
//     loginUser.send(JSON.stringify(payload));

// }