
function fetchReviews() {
    var request = new XMLHttpRequest();

    request.open('GET', review_url, true);

    //This command initiates the calling of the review api
    request.onload = function() {
    //get all the review records into the review array
    review_array = JSON.parse(request.responseText);
    };

    request.send();
}


//This function displays all the reviews of he restauratnt when the 'reviews' button is clicked
function showRestaurantReview(element) {
    document.getElementById("emptyReview").innerHTML = "No review yet. Create one now";
    var item = element.getAttribute("item");
    currentIndex = item;

    document.getElementById("review").textContent = "Review for " + restaurants_array[item].restaurantName;
    document.getElementById("ReviewBody").textContent = "";

    for (var i = 0; i < review_array.length; i++) {
        if (review_array[i].restaurantName.trim() == restaurants_array[item].restaurantName.trim()) {
            document.getElementById("emptyReview").innerHTML = "";
            selectedRestaurantId = restaurants_array[item]._id;
            star = "";
            var html = '<div class="text-center" style="width:100%;">                                                           \
                            <div class="card">                                                                                  \
                                <div class="card-body">                                                                         \
                                    <p class="card-text" id="rating' + i + '">' + review_array[i].review + "</p>               \
                                    <small>by " + review_array[i].userName + " @ " + review_array[i].datePosted + "</small>   \
                                </div>                                                                                          \
                            </div>                                                                                              \
                        </div>";
            document.getElementById("ReviewBody").insertAdjacentHTML('beforeend', html);

            var star = "";
            for (var j = 0; j < review_array[i].rating; j++) {
                console.log(i);
                star += "<img src='images/heart.png' style='width:50px' />";
            }
            var userName = sessionStorage.getItem("userName");
            if (userName == review_array[i].userName){
                star += "<img src='images/delete.png' class='edit' data-dismiss='modal' item='" + i + "' onClick='deleteReview(this)'/>";
                star += "<img src='images/edit.png' class='edit' data-toggle='modal' data-target='#editReviewModal' data-dismiss='modal' item='" + i + "' onClick='editReview(this)'/>";
            }
            document.getElementById("rating" + i).insertAdjacentHTML('beforebegin', star + "<br/>");
        }
    }
}



function newReview() {
    rating = 0;
    document.getElementById("userReview").value = "";
    document.getElementById("userName").value = sessionStorage.getItem("userName");
}



    
// This function sends the new review to the server to be added.
function addReview() {
    var review = new Object();
    review._id = null;
    review.res_id = restaurants_array[currentIndex]._id; // restaurant ID is needed by server to create new review
    var request = new XMLHttpRequest();

    request.open('GET', userProfiles_url, true);

    request.onload = function(){
        userProfiles_array = JSON.parse(request.responseText);
        userName = document.getElementById("userName").value;
        for(var i = 0; i < userProfiles_array.length; i++) {
            if(userName.trim() == userProfiles_array[i].userName.trim())
                review.user_id = userProfiles_array[i]._id;
        }
    

    review.review = document.getElementById("userReview").value; // Value from HTML input text
    review.datePosted = null; // Changing the datePosted to null instead of taking the timestamp on the client side;
    review.rating = rating;

    var postReview = new XMLHttpRequest(); // new HttpRequest instance to send review

    postReview.open("POST", review_url, true); //Use the HTTP POST method to send data to server

    postReview.setRequestHeader("Content-Type", "application/json");
    postReview.onload = function() {
        fetchReviews(); // fetch all reviews again so that the web page can have the new updated reviews.     
    };
// Convert the data in Review object to JSON format before sending to the server.
    postReview.send(JSON.stringify(review)); 
};
    request.send();
}

//This function deletes user review for a restaurant 
function deleteReview(element) {
    var response = confirm("Are you sure you want to delete this comment?");

    if (response == true){
        var item = element.getAttribute("item");
        var delete_review_url = review_url + "/" + review_array[item]._id;
        var eraseReview = new XMLHttpRequest();
        eraseReview.open("DELETE", delete_review_url, true);
        eraseReview.onload = function(){
            fetchReviews();
        };
        eraseReview.send();
    }
    
}

//This function will hide the existing modal and present a modal with the selected review
//so that the user can attempt to change the rating or restaurant review, but not the username
function editReview(element) {
    var item = element.getAttribute("item");

    currentIndex = item;

    document.getElementById("edituserName").value = review_array[item].userName;
    document.getElementById("edituserReview").value = review_array[item].review;
    console.log(review_array[item].rating);
    displayColorHeart('editpop', review_array[item].rating);
}



//This function sends the Review data to the server for updating
function updateReview() {
    var response = confirm("Are you sure you want to update this comment?");
    if (response == true) {
    var edit_review_url = review_url + "/" + review_array[currentIndex]._id;
    var updateReview = new XMLHttpRequest(); // new HttpRequest instance to send request to server
    updateReview.open("PUT", edit_review_url, true); //The HTTP method called 'PUT' is used here as we are updating data
    updateReview.setRequestHeader("Content-Type", "application/json");
    review_array[currentIndex].userName = document.getElementById("edituserName").value;
    review_array[currentIndex].review = document.getElementById("edituserReview").value;
    review_array[currentIndex].rating = rating;
    updateReview.onload = function() {
    fetchReviews();
    };
    updateReview.send(JSON.stringify(review_array[currentIndex]));
    }
}
    



//This function shows the number of coloured hearts accordingly
function displayColorHeart(classname, num) {
    var pop = document.getElementsByClassName(classname);
    var classTarget = "." + classname;
    for (let p of pop) {
    p.setAttribute("src", heartBWImage);
    }
    changeHeartImage(num, classTarget);
    }


//This function is to swap the black and white coloured heart image to 
//a coloured image when the user hovers over it
function rateIt(element) {
    var num = element.getAttribute("value");
    var classname = element.getAttribute("class");
    var hearts = document.getElementsByClassName(classname);
    var classTarget = "." + classname;


    //for loop to initiate the heart images to use black and white
    for (let heart of hearts){
        heart.setAttribute("src", heartBWImage);
    }
    changeHeartImage(num, classTarget);
}

// This function sets the rating and coloured images based on the value of the image tag when  
// the mouse cursor hovers over the Heart image.
function changeHeartImage(num, classTarget) {
    switch (eval(num)) {
        case 1:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", heartImage);
            rating = 1;
            break;
        case 2:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", heartImage);
            rating = 2;
            break;
        case 3:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='3']").setAttribute("src", heartImage);
            rating = 3;
            break;
        case 4:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='3']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='4']").setAttribute("src", heartImage);
            rating = 4;
            break;
        case 5:
            document.querySelector(classTarget + "[value='1']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='2']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='3']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='4']").setAttribute("src", heartImage);
            document.querySelector(classTarget + "[value='5']").setAttribute("src", heartImage);
            rating = 5;
            break;
    }
}




