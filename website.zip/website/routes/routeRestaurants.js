"use strict"
const restaurantdb = require('../models/RestaurantDB');

var restaurantDBObject = new restaurantdb();

function routeRestaurants(app){
    app.route('/restaurants')
        .get(restaurantDBObject.getAllRestaurants);
    app.route('/restaurants/searchbar')
        .post(restaurantDBObject.searchAllRestaurants);
    app.route('/email')
        .post(restaurantDBObject.sendEmail);
}
module.exports = {routeRestaurants};