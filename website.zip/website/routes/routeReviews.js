"use strict"

const reviewdb = require('../models/ReviewDB');

var reviewDBObject = new reviewdb();

function routeReviews(app){
    app.route('/reviews')
        .post(reviewDBObject.addReview)
        .get(reviewDBObject.getAllReviews);
    app.route('/reviewsdata')
        .get(reviewDBObject.getAllReviewsData);
    app.route('/reviews/:id')
        .put(reviewDBObject.updateReview)
        .delete(reviewDBObject.deleteReview);
}
module.exports = {routeReviews};