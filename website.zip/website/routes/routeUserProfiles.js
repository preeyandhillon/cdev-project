"use strict"

const userprofilesdb = require('../models/UserProfilesDB');

var usersDBObject = new userprofilesdb();

function routeUsers(app){
	app.route('/login')
        .post(usersDBObject.getLoginCredentials)
        .get(usersDBObject.getAllUsers);
        app.route('/signup')
        .post(usersDBObject.createUser);
        app.route('/users/:id')
        .put(usersDBObject.updateUserProfile)
        .delete(usersDBObject.deleteUsers);
        app.route('/user')
        .post(usersDBObject.getProfile);
        app.route('/update')
        .put(usersDBObject.updateUserProfile);


}
module.exports = {routeUsers};