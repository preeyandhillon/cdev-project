"use strict"

var db = require('../db-connection');
const Review = require('../models/Review');

class ReviewDB{
    getAllReviews(request, respond){
        var sql = "SELECT review._id, userProfiles.userName, restaurants.restaurantName, review.review, review.rating, review.datePosted, review.res_id FROM restaurant_review.review INNER JOIN restaurant_review.userProfiles ON review.user_id = userProfiles._id INNER JOIN restaurant_review.restaurants ON review.res_id = restaurants._id";
        db.query(sql, function(error, result){
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }

    addReview(request, respond){
        var now = new Date();
        var reviewObject = new Review(null, request.body.user_id, request.body.res_id,
             request.body.review, request.body.rating, now.toString());
        var sql = "INSERT INTO restaurant_review.review (user_id, res_id, review, rating, datePosted) VALUES(?, ?, ?, ?, ?)";

        var values = [reviewObject.getUser_Id(), reviewObject.getRes_Id(),
             reviewObject.getReview(), reviewObject.getRating(), reviewObject.getDatePosted()];

        db.query(sql, values, function (error, result){
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }


    getAllReviewsData(request, respond){
        var sql = "SELECT userprofiles.userName,  restaurants.restaurantName, review.review, review.rating, review.datePosted, review._id FROM ((review INNER JOIN userprofiles ON review.user_id = userprofiles._id) INNER JOIN restaurants ON review.res_id = restaurants._id)";
        db.query(sql, function(error, result){
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }

    deleteReview(request, respond){
        var reviewID = request.params.id;
        var sql = "DELETE FROM restaurant_review.review WHERE _id = ?";
        db.query(sql, reviewID, function (error, result) {
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }

    updateReview(request, respond){
        var now = new Date();

        var reviewObject = new Review(request.params.id, request.body.user_id ,request.body.res_id, request.body.review, request.body.rating, now.toString());
        
        var sql = "UPDATE restaurant_review.review SET review = ?, rating = ?, datePosted = ? WHERE _id = ?";
        var values = [reviewObject.getReview(), reviewObject.getRating(), reviewObject.getDatePosted(), reviewObject.getId()];
        db.query(sql, values, function (error, result) {
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
          });
    }

    
}
module.exports = ReviewDB;