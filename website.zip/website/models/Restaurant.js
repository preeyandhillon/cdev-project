"use strict"
class Restaurant{
    constructor(id, restaurantName, number, address, websiteAddress, openingHours, restaurantPrice, thumbnail, caroImage1, caroImage2, cuisine, neighbourhood, longitude, latitude, restaurantLocation){
        this.id = id;
        this.restaurantName = restaurantName;
        this.number = number;
        this.address = address;
        this.websiteAddress = websiteAddress;
        this.openingHours = openingHours;
        this.restaurantPrice = restaurantPrice;
        this.thumbnail = thumbnail;
        this.caroImage1 = caroImage1;
        this.caroImage2 = caroImage2;
        this.cuisine = cuisine;
        this.neighbourhood = neighbourhood;
        this.longitude = longitude;
        this.latitude = latitude;
        this.restaurantLocation = restaurantLocation;

    }

    getId(){
        return this.id;
    }
    
    getRestaurantName(){
        return this.restaurantName;
    }

    getNumber(){
        return this.number;
    }

    getAddress(){
        return this.address;
    }

    getWebsiteAddress(){
        return this.websiteAddress;
    }

    getOpeningHours(){
        return this.openingHours;
    }

    getRestaurantPrice(){
        return this.restaurantPrice;
    }

    getThumbnail(){
        return this.thumbnail;
    }

    getCaroImage1(){
        return this.caroImage1;
    }

    getCaroImage2(){
        return this.caroImage2;
    }
    getCuisine(){
        return this.cuisine;
    }

    getNeighbourhood(){
        return this.neighbourhood;
    }

    


    getLongitude(){
        return this.longitude;
    }
    getLatitude(){
        return this.latitude;
    }
    getRestaurantLocation(){
        return this.restaurantLocation;
    }

}

module.exports = Restaurant;
