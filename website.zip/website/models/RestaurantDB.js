"use strict"
var db = require('../db-connection');
const Restaurant = require('./Restaurant');
const sgMail = require('@sendgrid/mail')

class RestaurantDB {
    getAllRestaurants(request, respond) {
        var sql = "SELECT * FROM restaurant_review.restaurants";
        db.query(sql, function (error, result) {
            if (error) {
                throw error;
            }
            else {
                respond.json(result);
            }
        });
    }

    searchAllRestaurants(request, respond) {
        var key = "%" + request.body.search + "%";
        var sql = "SELECT * FROM restaurant_review.restaurants WHERE restaurantName LIKE ?";
        db.query(sql, [key], function (error, result) {
            if (error) {
                throw error;
            }
            else {
                respond.json(result);
            }
        });
    }


    filterRestaurant(request, respond) {
        var cuisine = request.body.cuisine
        var sql = "SELECT * FROM restaurant_review.restaurants WHERE cuisine = ?";
        db.query(sql, [cuisine], function (error, result) {
            if (error) {
                throw error;
            }
            else {
                respond.json(result);
            }
        });
    }

}

module.exports = RestaurantDB;