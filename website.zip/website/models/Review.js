"use strict"

class Review{
    constructor(id, user_id, res_id, review, rating, datePosted) {
        this.id = id;
        this.user_id = user_id;
        this.datePosted = datePosted;
        this.res_id = res_id;
        this.review = review;
        this.rating = rating;

    }

    getId(){
        return this.id;
    }
    getUser_Id(){
        return this.user_id;
    }
    getDatePosted(){
        return this.datePosted
    }
    getRes_Id(){
        return this.res_id;
    }
    getReview(){
        return this.review;
    }
    getRating(){
        return this.rating;
    }


    setUser_Id(user_id){
        this.user_id = user_id;
    }
    setRes_Id(res_id){
        this.res_id = res_id;
    }
    setReview(review){
        this.review = review;
    }
    setRating(rating){
        this.rating = rating;
    }
    setDatePosted(datePosted){
        this.datePosted = datePosted;
    }

}
module.exports = Review;
