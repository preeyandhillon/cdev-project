"use strict"

class users{
    constructor(id, userName, firstName, lastName, password, emailAddress, gender, address, number, profileImage){
        this.id = id;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.emailAddress = emailAddress;
        this.gender = gender;
        this.address = address;
        this.number = number;
        this.profileImage = profileImage;
    }
    getId(){
        return this.id;
    }
    getUserName(){
        return this.userName;
    }
    getFirstName(){
        return this.firstName;
    }
    getLastName(){
        return this.lastName;
    }
    getPassword(){
        return this.password;
    }
    getEmailAddress(){
        return this.emailAddress;
    }
    getGender(){
        return this.gender;
    }
    getAddress(){
        return this.address;
    }
    getNumber(){
        return this.number;
    }
    getProfileImage(){
        return this.profileImage;
    }

}
    module.exports = users;