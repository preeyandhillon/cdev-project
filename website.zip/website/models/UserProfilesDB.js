"use strict";
var db = require('../db-connection');
const User = require('../models/UserProfiles');
var jwt = require('jsonwebtoken')
var webtoken = require('jsonwebtoken')
var secretkey = "secretkey";

class userProfilesDB{

    createUser(request, respond){
        var userObject = new User(null, request.body.userName, request.body.firstName, request.body.lastName,
             request.body.password, request.body.emailAddress, request.body.gender, request.body.address, request.body.number, request.body.profileImage);
        var sql = "INSERT into restaurant_review.userprofiles (userName, firstName, lastName, password, emailAddress, gender, address, number, profileImage) VALUES(?,?,?,?,?,?,?,?,?)";

        var values = [userObject.getUserName(), userObject.getFirstName(), userObject.getLastName(), userObject.getPassword(),
             userObject.getEmailAddress(), userObject.getGender(), userObject.getAddress(),
             userObject.getNumber(), userObject.getProfileImage()];
        
             db.query(sql, values, function (error, result){
                if(error){
                    throw error;
                }
                else{
                    respond.json(result);
                }
            });
    }



    getLoginCredentials(request, respond){
        var userName = request.body.userName;
        var password = request.body.password;
 

        var sql = "SELECT password FROM restaurant_review.userprofiles WHERE userName = ?";

         db.query(sql, [userName], function (error, result) {
            if(error){
                throw error;
            }
            else{
                if(result.length > 0){
                    if(password == result[0].password){
                        var token = jwt.sign(userName, secretkey);
                        respond.json({result:token});
                        return;

                    }
                    else{
                        respond.json({result: false});
                    }
                }
                else{
                    msg = "USER NOT FOUND!";
                    respond.json({result: false});
                    $('#failModal').modal('show');
                }
                
            }
        });
    }

    getProfile(request, respond){
        var token = request.body.token;

        var sql = "SELECT distinct userName, password, emailAddress, profileImage FROM restaurant_review.userprofiles WHERE userName = ? "

        try{
            var decoded = jwt.verify(token, secretkey);
            db.query(sql, decoded, function (error, result){
                if (error){
                    respond.json(error);
                }
                else{
                    respond.json(result);
                }
            });
           

            } catch(err){
              respond.json({result:"invalid token"});
            }
    
    }   

    getAllUsers(request, respond){
        var sql = "SELECT * FROM restaurant_review.userprofiles";
        db.query(sql, function(error, result){
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }

    deleteUsers(request, respond){
        var userID = request.params.id;
        var sql = "DELETE FROM restaurant_review.userprofiles WHERE _id = ?";
        db.query(sql, userID, function (error, result) {
            if(error){
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }




    updateUserProfile(request, respond){
        var userObject = new User(request.params.id, request.body.userName, request.body.firstName, request.body.lastName,
             request.body.password, request.body.emailAddress, request.body.gender, request.body.address,
             request.body.number, request.body.profileImage);

        var sql = "UPDATE restaurant_review.userprofiles SET username = ?, firstName = ?, lastName = ?, password = ?, emailAddress = ?, gender = ?, address = ?, number = ?, profileImage = ? WHERE _id = ?";
        var values = [userObject.getUserName(), userObject.getFirstName(), userObject.getLastName(), userObject.getPassword(),
                      userObject.getEmailAddress(), userObject.getGender(), userObject.getAddress(), userObject.getNumber(), userObject.getProfileImage(), userObject.getId()];
        db.query(sql, values, function (error, result) {
            if(error){                                                                                                                                                                                                                                                                                                                                                                                                   
                throw error;
            }
            else{
                respond.json(result);
            }
        });
    }


    updateUserFirstName(request, respond){
       
        var userObject = new User(request.params.userName, request.body.firstName);

        var sql = "UPDATE restaurant_review.userprofiles SET firstName = ? WHERE userName = ?";
        var values = [userObject.getFirstName(), userObject.getUserName()];
        db.query(sql, values, function (error, result) {
            if(error){                                                                                                                                                                                                                                                                                                                                                                                                   
                throw error;
            }
            else{
                respond.json(result);
            }
          });
    }



    

}
function prepareMessage(msg){
    var obj = {"message": msg};
    return obj;
}



module.exports = userProfilesDB;